import { useState } from 'react'
import './App.css'
import { Button } from './components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs'

function App() {
  const [activeTab, setActiveTab] = useState('home')

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-amber-100">
      <header className="bg-amber-700 text-white shadow-md">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <img src="/saffron-logo.png" alt="زعفران ایرانی" className="h-12 w-12 mr-3" />
              <h1 className="text-2xl font-bold">زعفران طلایی ایران</h1>
            </div>
            <nav className="flex space-x-1 rtl:space-x-reverse">
              <Button 
                variant={activeTab === 'home' ? "default" : "ghost"} 
                onClick={() => setActiveTab('home')}
                className="text-white hover:text-amber-200"
              >
                صفحه اصلی
              </Button>
              <Button 
                variant={activeTab === 'products' ? "default" : "ghost"} 
                onClick={() => setActiveTab('products')}
                className="text-white hover:text-amber-200"
              >
                محصولات
              </Button>
              <Button 
                variant={activeTab === 'about' ? "default" : "ghost"} 
                onClick={() => setActiveTab('about')}
                className="text-white hover:text-amber-200"
              >
                درباره ما
              </Button>
              <Button 
                variant={activeTab === 'contact' ? "default" : "ghost"} 
                onClick={() => setActiveTab('contact')}
                className="text-white hover:text-amber-200"
              >
                تماس با ما
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsContent value="home" className="space-y-8">
            <section className="text-center py-12">
              <h2 className="text-3xl font-bold text-amber-800 mb-4">به دنیای طلای سرخ خوش آمدید</h2>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto">
                زعفران ایرانی، ارزشمندترین ادویه جهان با کیفیت بی‌نظیر، عطر دل‌انگیز و خواص درمانی فراوان
              </p>
              <div className="mt-8">
                <Button className="bg-amber-600 hover:bg-amber-700 text-white px-6 py-3 rounded-lg text-lg">
                  همین حالا خرید کنید
                </Button>
              </div>
            </section>

            <section className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="text-amber-700">کیفیت برتر</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>زعفران درجه یک ایرانی با بالاترین میزان کروسین، پیکروکروسین و سافرانال</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-amber-700">تضمین اصالت</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>تمامی محصولات دارای گواهی اصالت و کیفیت از معتبرترین آزمایشگاه‌های کشور</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-amber-700">ارسال سریع</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>بسته‌بندی حرفه‌ای و ارسال سریع به سراسر کشور و جهان</p>
                </CardContent>
              </Card>
            </section>

            <section className="bg-white rounded-lg shadow-md p-8 my-12">
              <h3 className="text-2xl font-bold text-amber-800 mb-6 text-center">چرا زعفران ایرانی؟</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-xl font-semibold text-amber-700 mb-3">خواص درمانی</h4>
                  <p className="text-gray-700">
                    زعفران سرشار از آنتی‌اکسیدان‌ها و ترکیبات فعال زیستی است که به بهبود سلامت قلب، تقویت سیستم ایمنی، 
                    کاهش استرس و اضطراب، بهبود خلق و خو و حتی پیشگیری از برخی بیماری‌ها کمک می‌کند.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-amber-700 mb-3">طعم و عطر بی‌نظیر</h4>
                  <p className="text-gray-700">
                    زعفران ایرانی با عطر و طعم منحصر به فرد خود، به غذاها، دسرها و نوشیدنی‌ها طعمی خاص و دلپذیر می‌بخشد 
                    که هیچ ادویه دیگری قادر به ایجاد آن نیست.
                  </p>
                </div>
              </div>
            </section>

            <section className="text-center py-8">
              <h3 className="text-2xl font-bold text-amber-800 mb-6">همکاری در فروش</h3>
              <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-8">
                شما هم می‌توانید با عضویت در سیستم همکاری در فروش ما، بدون نیاز به سرمایه اولیه و تنها با معرفی محصولات، 
                درآمد قابل توجهی کسب کنید.
              </p>
              <Button className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg text-lg">
                شروع همکاری
              </Button>
            </section>
          </TabsContent>

          <TabsContent value="products" className="space-y-8">
            <h2 className="text-3xl font-bold text-amber-800 mb-8 text-center">محصولات زعفران</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="overflow-hidden">
                <img src="/saffron-product-1.jpg" alt="زعفران سرگل ممتاز" className="w-full h-48 object-cover" />
                <CardHeader>
                  <CardTitle>زعفران سرگل ممتاز</CardTitle>
                  <CardDescription>بالاترین کیفیت زعفران ایرانی</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4">
                    زعفران سرگل ممتاز با رنگ‌دهی فوق‌العاده و عطر بی‌نظیر، مناسب برای مصارف آشپزی و خواص درمانی
                  </p>
                  <p className="text-lg font-bold text-amber-700">قیمت: تماس بگیرید</p>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-amber-600 hover:bg-amber-700">افزودن به سبد خرید</Button>
                </CardFooter>
              </Card>
              
              <Card className="overflow-hidden">
                <img src="/saffron-product-2.jpg" alt="زعفران پودر شده" className="w-full h-48 object-cover" />
                <CardHeader>
                  <CardTitle>زعفران پودر شده</CardTitle>
                  <CardDescription>آسیاب شده برای استفاده آسان</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4">
                    زعفران پودر شده با کیفیت عالی، مناسب برای استفاده سریع در انواع غذاها، دسرها و نوشیدنی‌ها
                  </p>
                  <p className="text-lg font-bold text-amber-700">قیمت: تماس بگیرید</p>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-amber-600 hover:bg-amber-700">افزودن به سبد خرید</Button>
                </CardFooter>
              </Card>
              
              <Card className="overflow-hidden">
                <img src="/saffron-product-3.jpg" alt="زعفران نگین" className="w-full h-48 object-cover" />
                <CardHeader>
                  <CardTitle>زعفران نگین</CardTitle>
                  <CardDescription>کیفیت درجه یک صادراتی</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4">
                    زعفران نگین با کلاله‌های بلند و یکدست، مناسب برای مصارف ویژه و هدیه دادن
                  </p>
                  <p className="text-lg font-bold text-amber-700">قیمت: تماس بگیرید</p>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-amber-600 hover:bg-amber-700">افزودن به سبد خرید</Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="about" className="space-y-8">
            <h2 className="text-3xl font-bold text-amber-800 mb-8 text-center">درباره ما</h2>
            
            <div className="bg-white rounded-lg shadow-md p-8">
              <p className="text-gray-700 mb-6">
                مجموعه زعفران طلایی ایران با بیش از یک دهه تجربه در زمینه تولید، بسته‌بندی و فروش زعفران اصیل ایرانی، 
                همواره در تلاش بوده تا بهترین و باکیفیت‌ترین محصولات را به مشتریان خود ارائه دهد.
              </p>
              
              <p className="text-gray-700 mb-6">
                ما با همکاری مستقیم با کشاورزان زحمتکش مناطق خراسان جنوبی و رضوی، زعفران را به صورت مستقیم و بدون واسطه 
                تهیه می‌کنیم و پس از طی مراحل استاندارد فرآوری و بسته‌بندی، آن را به دست مصرف‌کنندگان می‌رسانیم.
              </p>
              
              <p className="text-gray-700 mb-6">
                تمامی محصولات ما دارای گواهی کیفیت و اصالت بوده و تحت نظارت دقیق کارشناسان متخصص تولید می‌شوند. 
                ما به کیفیت محصولات خود افتخار می‌کنیم و رضایت مشتریان را مهم‌ترین سرمایه خود می‌دانیم.
              </p>
              
              <h3 className="text-xl font-bold text-amber-700 mt-8 mb-4">ماموریت ما</h3>
              <p className="text-gray-700">
                معرفی زعفران اصیل ایرانی به جهانیان و ارائه محصولی سالم، باکیفیت و اصیل به مصرف‌کنندگان در سراسر دنیا
              </p>
            </div>
          </TabsContent>

          <TabsContent value="contact" className="space-y-8">
            <h2 className="text-3xl font-bold text-amber-800 mb-8 text-center">تماس با ما</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="text-amber-700">اطلاعات تماس</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p><strong>آدرس:</strong> تهران، خیابان ولیعصر، پلاک 123</p>
                  <p><strong>تلفن:</strong> 021-12345678</p>
                  <p><strong>ایمیل:</strong> info@goldensaffron.ir</p>
                  <p><strong>ساعات کاری:</strong> شنبه تا پنجشنبه 9 الی 18</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-amber-700">فرم تماس</CardTitle>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">نام و نام خانوادگی</label>
                      <input type="text" className="w-full p-2 border rounded-md" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">ایمیل</label>
                      <input type="email" className="w-full p-2 border rounded-md" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">پیام</label>
                      <textarea className="w-full p-2 border rounded-md h-32"></textarea>
                    </div>
                    <Button className="w-full bg-amber-600 hover:bg-amber-700">ارسال پیام</Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="bg-amber-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-lg font-bold mb-4">زعفران طلایی ایران</h4>
              <p>ارائه دهنده بهترین و باکیفیت‌ترین زعفران ایرانی</p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">لینک‌های مفید</h4>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-amber-200">راهنمای خرید</a></li>
                <li><a href="#" className="hover:text-amber-200">نحوه ارسال</a></li>
                <li><a href="#" className="hover:text-amber-200">همکاری در فروش</a></li>
                <li><a href="#" className="hover:text-amber-200">سوالات متداول</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">شبکه‌های اجتماعی</h4>
              <div className="flex space-x-4 rtl:space-x-reverse">
                <a href="#" className="hover:text-amber-200">اینستاگرام</a>
                <a href="#" className="hover:text-amber-200">تلگرام</a>
                <a href="#" className="hover:text-amber-200">توییتر</a>
              </div>
            </div>
          </div>
          <div className="border-t border-amber-700 mt-8 pt-4 text-center">
            <p>© تمامی حقوق برای زعفران طلایی ایران محفوظ است.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
